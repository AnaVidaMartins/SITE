import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { motion } from "framer-motion";

export default function HorseVitrine() {
  return (
    <div className="min-h-screen bg-neutral-100 p-6">
      <h1 className="text-4xl font-semibold text-center mb-10">Horse – Marcas Artesanais</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Horse Cutelaria */}
        <motion.div whileHover={{ scale: 1.02 }}>
          <Card className="bg-white shadow-md rounded-2xl overflow-hidden">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">Horse Cutelaria</h2>
              <p className="text-base text-gray-600 mb-4">
                Lâminas artesanais com alma. Facas, canivetes e acessórios de cutelaria feitos à mão com excelência e identidade.
              </p>
              <Button variant="outline">Visitar loja</Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Horse & Thread */}
        <motion.div whileHover={{ scale: 1.02 }}>
          <Card className="bg-white shadow-md rounded-2xl overflow-hidden">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">Horse & Thread</h2>
              <p className="text-base text-gray-600 mb-4">
                Moda minimalista com bordado discreto. Camisas sociais e polos com estilo sutil e sofisticação natural.
              </p>
              <Button variant="outline">Visitar loja</Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
